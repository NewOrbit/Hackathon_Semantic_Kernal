import axios from "axios";

export class PromptApi {
    private readonly apiUrl: string = "https://localhost:7135";

    public async getDishes(query: string): Promise<string[]> {
        const response = await axios.get(`${this.apiUrl}/recipe/get-dishes/${query}`);
        const data = response.data;
        return data;
    }

    public async getRecipe(dish: string): Promise<string> {
        const response = await axios.get(`${this.apiUrl}/recipe/get-recipe/${dish}`);
        const data = response.data;
        return data;
    }

    public async getDishesFromImage(image: File): Promise<string[]> {
        const formData = new FormData();
        formData.append("file", image, image.name);

        const response = await axios.post(`${this.apiUrl}/recipe/get-dishes-img`, formData, {
            headers: {
                "Content-Type": "multipart/form-data"
            }
        });

        const data = response.data;
        return data;
    }
}
