import { useCallback, useState } from "react";

import Box from "@mui/material/Box";
import Stack from "@mui/material/Stack";
import BottomNavigation from "@mui/material/BottomNavigation";
import { Divider } from "@mui/material";

import { IngredientsInput } from "./components/IngredientsInput";
import { SendButton } from "./components/SendButton";
import { Response } from "./components/Response";
import { Recipies } from "./components/Recipies";
import { IngredientsDrawer } from "./components/Drawer";
import { PromptApi } from "./api/promptApi";
import { ImageUploadButton } from "./components/ImageUploadButton";

const App = () => {
  const [loading, setLoading] = useState<boolean>(false);
  const [response, setResponse] = useState<string>("");
  const [ingredients, setIngredients] = useState<string[]>([]);
  const [recipies, setRecipies] = useState<string[]>([]);

  const handleIngredientsOnChange = useCallback(
    (_: React.SyntheticEvent, value: string[]) => {
      setIngredients(value);
    },
    []
  );

  const handleSendIngredients = useCallback((data: string[]) => {
    setRecipies(data);
  }, []);

  const handleOnRecipeClick = useCallback(async (data: string) => {
    const getRecipe = async () => {
      const api = new PromptApi();
      setLoading(true);
      const response = await api.getRecipe(data);
      setResponse(response.replace("```markdown", "").replace("```", ""));
      setLoading(false);
    };

    getRecipe();
  }, []);

  const handleAddIngredient = useCallback((data: string) => {
    // TODO: Fix this to make it
    // TODO: Test to see if we need to call the other handlers
    setIngredients([...ingredients, data]);
  }, [ingredients]);

  const handleImageUpload = useCallback(async (image: File) => {
    const api = new PromptApi();
    const response = await api.getDishesFromImage(image);
    setLoading(true);
    setRecipies(response);
    setLoading(false);
  }, []);

  return (
    <>
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        height="100vh"
        textAlign="center"
      >
        <Stack width="100%" alignItems="center" justifyContent="center">
          <IngredientsDrawer onAddIngredient={handleAddIngredient} />
          <Stack width="50%" alignItems="center" justifyContent="center">
            <Response response={response} />
            <Stack width="100%" direction="row" alignItems="center">
              {/* TODO: fixing padding for smaller screen sizes */}
              <Box sx={{ position: "fixed", bottom: 0, left: 0, right: 0, padding: "0 30%", mb: "10px" }}>
                <Recipies recipies={recipies} getRecipe={handleOnRecipeClick} loading={loading} />
                <Divider hidden />
                <BottomNavigation>
                  <ImageUploadButton onImageUpload={handleImageUpload} />
                  <IngredientsInput ingredients={ingredients} onIngredientsChange={handleIngredientsOnChange} />
                  <SendButton ingredientsList={ingredients} onSendIngredients={handleSendIngredients} loading={loading} />
                </BottomNavigation>
              </Box>
            </Stack>
          </Stack>
        </Stack>
      </Box>
    </>
  );
};

export default App;
