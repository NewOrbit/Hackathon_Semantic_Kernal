import Autocomplete from "@mui/material/Autocomplete";
import Chip from "@mui/material/Chip";
import TextField from "@mui/material/TextField";
import { IngredientsList } from "../data/Ingredients";

interface IngredientsInputProps {
  ingredients: string[];
  onIngredientsChange: (event: React.SyntheticEvent, value: string[]) => void;
}

export const IngredientsInput = ({ ingredients, onIngredientsChange }: IngredientsInputProps) => {
  return (
    <Autocomplete
      multiple
      options={IngredientsList.map((option) => option)}
      defaultValue={ingredients}
      value={ingredients}
      freeSolo
      fullWidth
      renderTags={(value: readonly string[], getTagProps) =>
        value.map((option: string, index: number) => {
          const { key, ...tagProps } = getTagProps({ index });
          return (
            <Chip variant="outlined" label={option} key={key} {...tagProps} />
          );
        })
      }
      renderInput={(params) => (
        <TextField
          {...params}
          variant="outlined"
          label="Ingredients list (enter to add)"
        />
      )}
      onChange={onIngredientsChange}
    />
  );
};
