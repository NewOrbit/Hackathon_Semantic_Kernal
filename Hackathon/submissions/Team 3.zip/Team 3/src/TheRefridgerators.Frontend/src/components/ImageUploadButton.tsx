import Button from "@mui/material/Button"
import CloudUploadIcon from '@mui/icons-material/CloudUpload';

interface ImageUploadButtonProps {
    onImageUpload: (image: File) => void;
}

export const ImageUploadButton = ({ onImageUpload }: ImageUploadButtonProps) => {
    return (
        <Button
            component="label"
            role={undefined}
            variant="contained"
            sx={{ padding: '0px 50px' }}
            tabIndex={-1}
            startIcon={<CloudUploadIcon />}
        >
            Upload&nbsp;Image
            <input style={{
                clip: 'rect(0 0 0 0)',
                clipPath: 'inset(50%)',
                height: 1,
                overflow: 'hidden',
                position: 'absolute',
                bottom: 0,
                left: 0,
                whiteSpace: 'nowrap',
                width: 1,
            }}
                type="file"
                onChange={(event) => {
                    const file = event.target.files?.item(0);
                    if (file) {
                        onImageUpload(file);
                    }
                }}
                multiple
            />
        </Button>
    )
}