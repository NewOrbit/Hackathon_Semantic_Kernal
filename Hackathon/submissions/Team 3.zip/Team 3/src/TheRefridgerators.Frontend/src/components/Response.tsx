import Markdown from "react-markdown";

interface ResponseProps {
    response: string;
}

export const Response = ({ response }: ResponseProps) => {
    return (<>
        <Markdown>{response}</Markdown>
    </>);
};
