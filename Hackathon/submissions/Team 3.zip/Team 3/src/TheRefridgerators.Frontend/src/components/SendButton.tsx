import { Button } from "@mui/material";
import { PromptApi } from "../api/promptApi";
import ArrowCircleUpIcon from '@mui/icons-material/ArrowCircleUp';
import { useCallback } from "react";

export interface SendButtonProps {
  ingredientsList: string[];
  onSendIngredients: (data: string[]) => void;
  loading: boolean;
}

export const SendButton: React.FC<SendButtonProps> = ({ ingredientsList, onSendIngredients, loading }) => {
  const send = useCallback(async () => {
    const api = new PromptApi();
    const response = await api.getDishes(ingredientsList.join(","));
    onSendIngredients(response);
  }, [ingredientsList, onSendIngredients]);

  return (
    <Button onClick={send} disabled={loading}>
      <ArrowCircleUpIcon fontSize="large" />
    </Button>
  );
};
