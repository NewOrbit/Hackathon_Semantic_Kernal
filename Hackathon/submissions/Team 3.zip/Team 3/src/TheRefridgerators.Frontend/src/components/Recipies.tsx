import { Button } from "@mui/material";
import SendIcon from '@mui/icons-material/Send';

interface RecipiesProps {
    recipies: string[];
    getRecipe: (recipe: string) => Promise<void>;
    loading: boolean;
}

export const Recipies: React.FC<RecipiesProps> = ({ recipies, getRecipe, loading }: RecipiesProps) => {
    return (<>
        {recipies.map((recipie, index) => (
            <Button
                key={index}
                variant="outlined"
                endIcon={<SendIcon />}
                onClick={() => getRecipe(recipie)}
                disabled={loading}
            >
                {recipie}
            </Button>
        ))}
    </>);
};