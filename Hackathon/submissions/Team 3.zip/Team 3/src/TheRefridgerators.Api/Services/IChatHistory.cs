﻿using Microsoft.SemanticKernel.ChatCompletion;

namespace TheRefridgerators.Api.Services;

public interface IChatHistory
{
    ChatHistory ChatHistory { get; }
}
