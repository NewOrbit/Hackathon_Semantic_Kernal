﻿using Microsoft.SemanticKernel.ChatCompletion;

namespace TheRefridgerators.Api.Services;

public class SingletonChatHistory : IChatHistory
{
    public ChatHistory ChatHistory { get; }

    public SingletonChatHistory()
    {
        this.ChatHistory = new ChatHistory();
    }
}
