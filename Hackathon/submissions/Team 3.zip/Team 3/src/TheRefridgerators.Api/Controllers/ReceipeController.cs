using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.CognitiveServices.Speech;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;
using TheRefridgerators.Api.Services;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace TheRefridgerators.Api.Controllers;

[ApiController]
[Route("/recipe")]
public class ReceipeController : ControllerBase
{
    private IChatCompletionService chatCompletionService;
    private IChatHistory chatHistoryProvider;

    public ReceipeController(IChatCompletionService chatCompletionService, IChatHistory chatHistoryProvider)
    {
        this.chatCompletionService = chatCompletionService;
        this.chatHistoryProvider = chatHistoryProvider;
    }

    [HttpGet("get-dishes/{query}")]
    public async Task<IActionResult> GetDishes(string query)
    {
        chatHistoryProvider.ChatHistory.Clear();
        var whatAmI = "Chef who has knowledge of lots of simple recipes";
        chatHistoryProvider.ChatHistory.AddSystemMessage(whatAmI!);

        var prompt = "tell me some names of dishes that I can make with " + query + ". Give just an unordered list of names withiout any bulletpoints.";
        chatHistoryProvider.ChatHistory.AddUserMessage(prompt!);

        var response = await this.chatCompletionService.GetChatMessageContentsAsync(chatHistoryProvider.ChatHistory);
        var lastMessage = response.Last();
        var dishes = lastMessage?.Content?.Split("\n");


        return Ok(dishes);
    }

    [HttpGet("get-recipe/{dish}")]
    public async Task<IActionResult> GetRecipe(string dish)
    {
        var prompt = "Can you give me a recipe for the " + dish + " dish? I need just ingridients and method, no extra text and put it in a markdown format";
        chatHistoryProvider.ChatHistory.AddUserMessage(prompt!);

        var response = await this.chatCompletionService.GetChatMessageContentsAsync(chatHistoryProvider.ChatHistory);
        var lastMessage = response.Last();

        return Ok(lastMessage.Content);
    }

    [HttpPost("get-dishes-img")]
    public async Task<IActionResult> GetDishesImg(IFormFile file)
    {
        chatHistoryProvider.ChatHistory.Clear();
        var whatAmI = "Chef who has knowledge of lots of simple recipes";
        chatHistoryProvider.ChatHistory.AddSystemMessage(whatAmI!);

        using var stream = new MemoryStream();
        await file.CopyToAsync(stream);
        var fileContent = stream.ToArray();

        var chatMessageContentItemCollection = new ChatMessageContentItemCollection
            {
                new ImageContent(fileContent, file.ContentType),
                new TextContent("Tell me some names of dishes that I can make with the ingridients that you can see on this picture. Give just an unordered list of names withiout any bulletpoints.")
            };

        chatHistoryProvider.ChatHistory.AddUserMessage(chatMessageContentItemCollection);

        var response = await this.chatCompletionService.GetChatMessageContentsAsync(chatHistoryProvider.ChatHistory);
        var lastMessage = response.Last();
        var dishes = lastMessage?.Content?.Split("\n");

        return Ok(dishes);
    }

    [HttpPost("get-dishes-img-to-voice")]
    public async Task<IActionResult> GetDishesImgToVoice(IFormFile file)
    {
        chatHistoryProvider.ChatHistory.Clear();
        var whatAmI = "Chef who has knowledge of lots of simple recipes";
        chatHistoryProvider.ChatHistory.AddSystemMessage(whatAmI!);

        var speechConfig = SpeechConfig.FromSubscription("086fc0fa53ba49209897abe557f9f8ef", "eastus");
        speechConfig.SpeechSynthesisVoiceName = "en-US-AvaMultilingualNeural";

        using var stream = new MemoryStream();
        await file.CopyToAsync(stream);
        var fileContent = stream.ToArray();

        var chatMessageContentItemCollection = new ChatMessageContentItemCollection
            {
                new ImageContent(fileContent, file.ContentType),
                new TextContent("Tell me some names of dishes that I can make with the ingridients that you can see on this picture. Give just an unordered list of names 3 withiout any bulletpoints.")
            };

        chatHistoryProvider.ChatHistory.AddUserMessage(chatMessageContentItemCollection);

        var response = await this.chatCompletionService.GetChatMessageContentsAsync(chatHistoryProvider.ChatHistory);
        var lastMessage = response.Last();
        var dishes = lastMessage?.Content?.Split("\n");

        using (var speechSynthesizer = new SpeechSynthesizer(speechConfig))
        {
            var speechSynthesisResult = await speechSynthesizer.SpeakTextAsync(lastMessage.Content);
            return Ok(speechSynthesisResult.AudioData);
        }
    }
}
