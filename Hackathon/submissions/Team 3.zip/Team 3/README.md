# Semantic Kernel Hackathon - Team 3

## AZURE ENV CREDENTIALS: 

https://semantic-kernel-hackhaton.openai.azure.com/
Model name: gpt-4o 
Model version: 2024-08-06
East US 2

## Brainstorming and problem breakdown

Emphasize:
==========
I spend lots of money on food that I don't use
I waste a lot of food
I spend lots of time trying to find recipes that use the food I have
I end up having the same old meals 

Define:
=======
Our problem statement

We want assistance to help provide meals ideas to combat the problems listed above

In a world where cooking creativity meets the constraints of time and ingredient availability, many people struggle to come up with recipe ideas based on the ingredients they have on hand. Traditional recipe apps require users to manually input ingredients or search through databases, which can be tedious, especially for those unfamiliar with cooking terminology. Furthermore, these tools often lack personalization based on dietary preferences, meal type, or flavour profiles, which limits their usefulness in meeting individual needs.
Solution Phases:
Phase 1 - Text-Based Ingredient Recognition:
Users can input a list of ingredients via text, and the app will generate recipe suggestions based on these ingredients.
Phase 2 - Photo-Based Ingredient Recognition:
Building on the text feature, users can take a photo of their ingredients, and the app will automatically recognize the items and suggest relevant recipes, making it even easier and more intuitive.
Phase 3 - Meal Type Personalization:
The app will refine its suggestions further by allowing users to filter recipes based on their desired meal type (e.g., spicy, dessert, snack, breakfast), dietary needs, or flavour preferences.

Ideate:
=======
## Solutions
### Phase 1 - backend. (with postman)
- Text Input Prompt => ingredients and type of meal we want, (breakfast, snack, etc) 
- Response => a list of dishes (name and image) matching most of the ingredients
- Number Selection => Pick as number against a specific recipe
- Response => Ingredients, method (use the chat history)

### Phase 2 - web with backend.
Images and Text Input => Images of food in the fridge and cupboards with the type of meal we want
Response => a spoken list of dishes and images matching most of the ingredients
Voice Input => "Stir fry please"
Response => Ingredients, method (use the chat history)

### Phase 3 - web with backend.
- Voice Input => "Tell me what the first ingredient is"
- Voice Response => "Peel an onion"
- Voice Input => "Next step please"
- Voice Response => "Grate 100 grams of cheese"
 - etc.

### Phase 4
- AI create a video for you to follow with the 

### Phase 5
- Get ChatGPT/ROBOT to take the photo and cook the meals 

## Task Breakdown

### Tasks
-----

- Resources set up (chatgpt 4.o)
- GitHub repo (Jarek)
- Share the endpoint and secrets in the chat (appsettings)

[Mateusz, Ula, Paul]
1. Phase 1 Backend (2 endpoints), store history, in singleton
reset singleton on hitting the first endpoint.

/recipe/get/{query: string}
```json
// returns
{
 ["Spagetti bolognaise", "Lasagna"]
}
```

/recipe/getIngredients{dish: string} 
```
{
  "Ingredients ......, Method ........."
}
```

[Jarek, Billy, Craig]

2. Phase 2 Web frontend (no security)
react - mui - axios
upload image

3. Phase 2 Backend endpoint, to respond to image upload 

4. Phase 2 frontend voice input

5. Phase 2 Backend endpoint, to respond to voice input

--------------------------------------

6. Phase 3 frontend first ingredient voice input

7. Phase 3 Backend endpoint, return spoken ingredient

8. Phase 3 frontend next ingredient 

9. Phase 3 Backend endpoint, return spoken next ingredient





