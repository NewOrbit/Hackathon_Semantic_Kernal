﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;
using NewOrbitHackathonProject;

var builder = Host.CreateDefaultBuilder(args) // Creates a host builder with default settings
    .ConfigureAppConfiguration((context, config) =>
    {
        config.AddUserSecrets<Program>(); // Add user secrets to the configuration pipeline
    })
    .ConfigureServices((context, services) =>
    {
        var kernelSettings = context.Configuration.Get<KernelSettings>();

        if (string.IsNullOrEmpty(kernelSettings?.AzureOpenAiKey))
        {
            throw new InvalidOperationException("Azure OpenAI Key is missing in user secrets or environment variables.");
        }

        services.AddAzureOpenAIChatCompletion(
            "NewOrbit-Hackathon-Resource",
            "https://neworbit-hackathon-resource.openai.azure.com/",
            kernelSettings.AzureOpenAiKey,
            modelId: "gpt-4o"
        );
    });

var app = builder.Build();

var chat = app.Services.GetRequiredService<IChatCompletionService>();

var chatHistory = new ChatHistory(
    @"You are botivator! One and only bot created to motivate people. Diagnose what people are writing to you - if you find out that they're having
                bad time or making bad decisions, try to motivate them to be better. Remember, you're not a therapist, you're a friend. You're here to help them.
                You're here to make them better. You're here to make them happy. You're here to make them successful. You're here to make them feel good about
                themselves. You're here to make them feel like they can do anything. You're here to make them feel like they're worth it. Don't be rude.
                Don't be mean. Don't be negative. Don't be judgmental. Don't be harsh. Don't be sarcastic. Don't finish the conversation, unless user wants to.");

Console.ForegroundColor = ConsoleColor.Green;
Console.WriteLine("How can I help?");
Console.ForegroundColor = ConsoleColor.Yellow;

while (true)
{
    var prompt = Console.ReadLine();
    chatHistory.AddUserMessage(prompt!);

    Console.ForegroundColor = ConsoleColor.Green;
    Console.WriteLine("Botivator: ");
    var response = await chat.GetChatMessageContentsAsync(chatHistory);
    var lastMessage = response.Last();
    chatHistory.AddSystemMessage(lastMessage.ToString());
    Console.WriteLine(lastMessage);
}

// You can create a kernal and pass it to `GetChatMessageContentsAsync`, you can add plugins to this kernal to control the behavior of the AI 
// https://learn.microsoft.com/en-us/semantic-kernel/get-started/quick-start-guide?pivots=programming-language-csharp

// detailed samples
// https://learn.microsoft.com/en-us/semantic-kernel/get-started/detailed-samples?pivots=programming-language-csharp