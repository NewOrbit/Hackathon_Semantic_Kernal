"use client";

import { useMemo, useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  SendIcon,
  QuoteIcon,
  Settings,
  LogIn,
  LogOut,
  User,
  Bell,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { SiChatbot } from "react-icons/si";
import { PiForkKnifeBold } from "react-icons/pi";
import { FaCalendarAlt } from "react-icons/fa";
import { TbShoe } from "react-icons/tb";
import { ChatHeaderBg } from "./ui/chat-header-bg";

const quotes = [
  "The only way to do great work is to love what you do. - Steve Jobs",
  "Believe you can and you're halfway there. - Theodore Roosevelt",
  "Success is not final, failure is not fatal: it is the courage to continue that counts. - Winston Churchill",
  "The future belongs to those who believe in the beauty of their dreams. - Eleanor Roosevelt",
  "Strive not to be a success, but rather to be of value. - Albert Einstein",
];

function ChatBubble({
  message,
  isBot,
  timestamp,
}: {
  message: string;
  isBot: boolean;
  timestamp: Date;
}) {
  const formattedTime = timestamp.toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  });

  return (
    <div
      className={`flex items-end gap-2 mb-4 ${
        isBot ? "justify-start" : "justify-end"
      }`}
    >
      {isBot && (
        <Avatar className="w-8 h-8">
          <AvatarImage src="/placeholder-bot.png" alt="Bot" />
          <AvatarFallback>CM</AvatarFallback>
        </Avatar>
      )}
      {!isBot && (
        <div className="text-xs text-gray-500 self-start mt-1">
          {formattedTime}
        </div>
      )}
      <div
        className={`rounded-lg px-4 py-2 max-w-[70%] font-semibold text-start drop-shadow-md ${
          isBot ? "bg-green-200 text-black" : "bg-pink-400 text-white"
        }`}
      >
        {message}
      </div>
      {isBot && (
        <div className="text-xs text-gray-500 font-semibold self-end mt-1">
          {formattedTime}
        </div>
      )}
    </div>
  );
}

function NavItem({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-center space-x-3 mb-4">
      <div className="bg-orange-200 p-2 rounded-full">{icon}</div>
      <div>
        <p className="text-sm font-medium text-gray-600">{label}</p>
        <p className="text-lg font-bold text-gray-800">{value}</p>
      </div>
    </div>
  );
}

function LeftNavItem({
  icon,
  label,
}: {
  icon: React.ReactNode;
  label: string;
}) {
  return (
    <Button variant="outline" className="w-full justify-start mb-2">
      {icon}
      <span className="ml-2">{label}</span>
    </Button>
  );
}

export function MotivationalChatWithCoachCardLeftAvatar() {
  const [messages, setMessages] = useState<
    Array<{ text: string; isBot: boolean; timestamp: Date }>
  >([
    {
      text: "Hi there! I'm Coach Mike. How can I motivate you today?",
      isBot: true,
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");

  const handleSend = async () => {
    if (input.trim()) {
      const newMessage = { text: input, isBot: false, timestamp: new Date() };
      setMessages((prev) => [...prev, newMessage]);
      setInput("");

      const response = await fetch("/api/chat/handleMessage", {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ sessionId: "test", message: input }),
      });
      const json = await response.json();
      const botMessage = {
        text: json,
        isBot: true,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, botMessage]);
    }
  };

  const randomQuote = useMemo(
    () => quotes[Math.floor(Math.random() * quotes.length)],
    []
  );

  return (
    <div className="flex font-sans h-full mx-auto bg-green-50 shadow-xl overflow-hidden">
      {/* Left Navigation Panel (Menu) */}
      <div className="w-64 bg-gradient-to-b from-emerald-800 to-emerald-500 p-6 flex flex-col">
        <h2 className="text-2xl font-bold text-white mb-6 flex justify-center items-center gap-2">
          <SiChatbot size="35px" /> BotivateMe
        </h2>

        <div className="flex">
          <div className="stroke-white stroke-3"></div>
        </div>
        <LeftNavItem icon={<User className="h-4 w-4" />} label="Profile" />
        <LeftNavItem
          icon={<Bell className="h-4 w-4" />}
          label="Notifications"
        />
        <LeftNavItem icon={<Settings className="h-4 w-4" />} label="Settings" />
        <div className="mt-auto">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" className="w-full">
                <User className="mr-2 h-4 w-4" />
                <span>Account</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56">
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <LogIn className="mr-2 h-4 w-4" />
                <span>Log In</span>
              </DropdownMenuItem>
              <DropdownMenuItem>
                <LogOut className="mr-2 h-4 w-4" />
                <span>Log Out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Right Navigation Panel (Progress) */}
      <div className="w-64 m-12 flex flex-1 flex-col gap-10 items-start">
        <div className="flex flex-col gap-1 text-emerald-800">
          <h2 className="text-2xl font-bold">Welcome back, user!</h2>
          <h2 className="text-xl mb-6">Here's your journey so far:</h2>
        </div>

        <div className="flex flex-col gap-5 w-full">
          <div className="flex pr-20 w-full">
            <div className="flex w-full justify-between p-6 rounded-2xl bg-slate-700 text-green-50">
              <PiForkKnifeBold size="64px" />
              <div className="flex-col">
                <div className="text-4xl font-semibold">228</div> kcal skipped
              </div>
            </div>
          </div>

          <div className="flex pr-14 pl-7 w-full">
            <div className="flex w-full justify-between p-6 rounded-2xl bg-slate-700 text-green-50">
              <FaCalendarAlt size="64px" />
              <div className="flex-col">
                <div className="text-4xl font-semibold">2</div> active days
              </div>
            </div>
          </div>

          <div className="flex pr-7 pl-14 w-full">
            <div className="flex w-full justify-between p-6 rounded-2xl bg-slate-700 text-green-50">
              <TbShoe size="64px" />
              <div className="flex-col">
                <div className="text-4xl font-semibold">8 768</div> steps taken
              </div>
            </div>
          </div>
        </div>

        <div className="mt-auto flex w-full flex-col">
          <h3 className="text-lg text-start font-semibold text-gray-800 mb-2">
            Quote of the Day:
          </h3>
          <div className="bg-emerald-800 p-4 rounded-lg">
            <QuoteIcon className="text-white mb-2" />
            <p className="text-sm text-white italic">{randomQuote}</p>
          </div>
        </div>
      </div>

      {/* Chat Interface */}
      <div className="flex-1 flex flex-col z-10">
        {/* Coach Mike Card */}
        <div className="m-4 relative">
          <div className="drop-shadow-md absolute z-0">
            <ChatHeaderBg />
          </div>
          <div className="p-8 pl-10 flex items-center z-1 relative">
            <Avatar className="w-12 h-12 mr-4">
              <AvatarImage src="/placeholder-coach.png" alt="Coach Mike" />
              <AvatarFallback>CM</AvatarFallback>
            </Avatar>

            <div className="flex flex-col justify-start">
              <h2 className="text-2xl font-bold text-white text-start">
                Coach Mike
              </h2>
              <p className="text-sm text-white">
                Your Personal Motivation Assistant
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-col flex-1 drop-shadow-xl">
          <div className="flex-1 overflow-y-auto p-4 pt-20 flex flex-col">
            {messages.map((message, index) => (
              <ChatBubble
                key={index}
                message={message.text}
                isBot={message.isBot}
                timestamp={message.timestamp}
              />
            ))}
          </div>
          <div className="p-4 bg-white">
            <div className="flex space-x-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSend()}
                placeholder="Type your message..."
                className="flex-1"
              />
              <Button
                onClick={handleSend}
                className="bg-green-500 hover:bg-green-600"
              >
                <SendIcon className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
