﻿namespace BotivateMe.Controllers;

using BotivateMe.Interfaces;
using BotivateMe.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.SemanticKernel.ChatCompletion;

[Route("api/chat")]
[ApiController]
public class ChatController
{
    private readonly IChatService _chatService;
    private readonly IChatHistoryService _chatHistoryService;
    
    public ChatController(IChatService chatService, IChatHistoryService chatHistoryService)
    {
        this._chatService = chatService;
        this._chatHistoryService = chatHistoryService;
    }
    
    [HttpGet("history/{sessionId}")]
    public IEnumerable<OldChatHistoryModel> GetChatHistory(string sessionId)
        => _chatHistoryService.GetOldChatHistory(sessionId);

    [HttpPost("handleMessage")]
    public Task<string> HandleMessage([FromBody] MessageModel model)
        => _chatService.GetChatMessageContentsAsync(model.SessionId, model.Message);
    
    [HttpPost("streamMessage")]
    public async IAsyncEnumerable<string> StreamMessage([FromBody] MessageModel model)
    {
        await foreach (var message in _chatService.GetChatMessageStreamAsync(model.SessionId, model.Message))
        {
            yield return message;
        }
    }
}