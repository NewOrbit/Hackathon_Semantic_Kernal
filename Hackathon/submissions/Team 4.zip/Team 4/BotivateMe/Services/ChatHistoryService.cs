﻿namespace BotivateMe.Services;

using BotivateMe.Interfaces;
using BotivateMe.Models;
using Microsoft.SemanticKernel.ChatCompletion;

public class ChatHistoryService : IChatHistoryService
{
    private readonly Dictionary<string, ChatHistory> _chatHistories;

    public ChatHistoryService()
    {
        _chatHistories = new Dictionary<string, ChatHistory>();
    }

    public IEnumerable<OldChatHistoryModel> GetOldChatHistory(string sessionId)
    {
        if (_chatHistories.TryGetValue(sessionId, out var chatHistory))
        {
            List<OldChatHistoryModel> chatHistoryModels = new List<OldChatHistoryModel>();
            
            foreach (var message in chatHistory.Skip(1))
            {
                chatHistoryModels.Add(new OldChatHistoryModel
                {
                    IsBot = message.Role == AuthorRole.System,
                    Message = message.Content
                });
            }

            return chatHistoryModels;
        }

        return Enumerable.Empty<OldChatHistoryModel>();
    }

    public Task<ChatHistory> GetChatHistoryAsync(string sessionId)
    {
        if (_chatHistories.TryGetValue(sessionId, out var chatHistory))
        {
            return Task.FromResult(chatHistory);
        }

        return Task.FromResult(new ChatHistory(
                @"You are botivator! One and only bot created to motivate people. Diagnose what people are writing to you - if you find out that they're having
                bad time or making bad decisions, try to motivate them to be better. Remember, you're not a therapist, you're a friend. You're here to help them.
                You're here to make them better. You're here to make them happy. You're here to make them successful. You're here to make them feel good about
                themselves. You're here to make them feel like they can do anything. You're here to make them feel like they're worth it. Don't be rude.
                Don't be mean. Don't be negative. Don't be judgmental. Don't be harsh. Don't be sarcastic. Don't finish the conversation, unless user wants to."));
    }

    public Task SaveChatHistoryAsync(string sessionId, ChatHistory chatHistory)
    {
        _chatHistories[sessionId] = chatHistory;
        return Task.CompletedTask;
    }
}