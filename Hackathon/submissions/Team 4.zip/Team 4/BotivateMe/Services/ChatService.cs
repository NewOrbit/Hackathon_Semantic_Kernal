﻿namespace BotivateMe.Services;

using BotivateMe.Interfaces;
using Microsoft.SemanticKernel;
using Microsoft.SemanticKernel.ChatCompletion;
using Microsoft.SemanticKernel.Connectors.OpenAI;

public class ChatService(Kernel kernel, IChatHistoryService historyService) : IChatService
{
    private readonly IChatCompletionService _chatService =
        kernel.GetRequiredService<IChatCompletionService>();

    public async Task<string> GetChatMessageContentsAsync(string sessionId, string messageInput)
    {
        var chatHistory = await historyService.GetChatHistoryAsync(sessionId);
        chatHistory.AddUserMessage(messageInput);

        var executionSettings = new OpenAIPromptExecutionSettings
        {
            ToolCallBehavior = ToolCallBehavior.AutoInvokeKernelFunctions
        };
        var response = await _chatService.GetChatMessageContentsAsync(chatHistory, executionSettings, kernel: kernel);
        
        var lastMessage = response.Last().ToString();
        chatHistory.AddSystemMessage(lastMessage);
        
        await historyService.SaveChatHistoryAsync(sessionId, chatHistory);
        
        return lastMessage;
    }

    public async IAsyncEnumerable<string> GetChatMessageStreamAsync(string sessionId, string messageInput)
    {
        var chatHistory = await historyService.GetChatHistoryAsync(sessionId);
        chatHistory.AddUserMessage(messageInput);

        var fullResult = string.Empty;
 
        var executionSettings = new OpenAIPromptExecutionSettings
        {
            ToolCallBehavior = ToolCallBehavior.AutoInvokeKernelFunctions
        };
        await foreach (var result in _chatService.GetStreamingChatMessageContentsAsync(chatHistory, executionSettings, kernel: kernel))
        {
            fullResult += result;
            await Task.Delay(100);
            yield return result.ToString();
        }
        
        chatHistory.AddSystemMessage(fullResult);
        
        await historyService.SaveChatHistoryAsync(sessionId, chatHistory);
    }
}