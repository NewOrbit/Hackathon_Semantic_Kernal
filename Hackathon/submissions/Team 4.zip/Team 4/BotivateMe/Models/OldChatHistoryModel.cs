﻿namespace BotivateMe.Models;

public class OldChatHistoryModel
{
    public string Message { get; set; }
    
    public bool IsBot { get; set; }
}