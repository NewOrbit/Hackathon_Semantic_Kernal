﻿namespace BotivateMe.Models;

public class MessageModel
{
    public string SessionId { get; set; }

    public string Message { get; set; }
}