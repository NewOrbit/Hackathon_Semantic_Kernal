﻿namespace BotivateMe.Interfaces;

using BotivateMe.Models;
using Microsoft.SemanticKernel.ChatCompletion;

public interface IChatHistoryService
{
    IEnumerable<OldChatHistoryModel> GetOldChatHistory(string sessionId);
    
    Task<ChatHistory> GetChatHistoryAsync(string sessionId);

    Task SaveChatHistoryAsync(string sessionId, ChatHistory chatHistory);
}