﻿namespace BotivateMe.Interfaces;

public interface IChatService
{
    Task<string> GetChatMessageContentsAsync(string sessionId, string messageInput);

    IAsyncEnumerable<string> GetChatMessageStreamAsync(string sessionId, string messageInput);
}