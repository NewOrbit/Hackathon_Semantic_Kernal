﻿namespace BotivateMe.Plugins;

using System.ComponentModel;
using Microsoft.SemanticKernel;

public class WeatherPlugin
{
    private static string _apiKey;

    public static void Configure(string apiKey)
    {
        _apiKey = apiKey;
    }

    [KernelFunction("get_weather")]
    [Description("When user provides us with place he wants to do activity, we should check the weather, this can be used for that")]
    [return: Description("Weather information in json format")]
    public async Task<string> GetWeather(Kernel kernel, string city)
    {
        HttpClient client = new HttpClient();
        var response = await client.GetAsync($"https://api.openweathermap.org/data/2.5/weather?q={city}&appid={_apiKey}");
        return await response.Content.ReadAsStringAsync();
    }
}