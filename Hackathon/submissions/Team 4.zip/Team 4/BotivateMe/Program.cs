using BotivateMe.Interfaces;
using BotivateMe.Plugins;
using BotivateMe.Services;
using Microsoft.SemanticKernel;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();


builder.Services.AddTransient<Kernel>(_ =>
{
    var kernelBuilder = Kernel.CreateBuilder();

    kernelBuilder.AddAzureOpenAIChatCompletion(
        "NewOrbit-Hackathon-Resource",
        "https://neworbit-hackathon-resource.openai.azure.com/",
        builder.Configuration["AzureOpenAiKey"],
        modelId: "gpt-4o"
    );

    WeatherPlugin.Configure(builder.Configuration["OpenWeatherMapApiKey"]);
    kernelBuilder.Plugins.AddFromType<WeatherPlugin>();

    // Build and return the kernel
    var kernel = kernelBuilder.Build();
    return kernel;
});


builder.Services.AddSingleton<IChatHistoryService, ChatHistoryService>();
builder.Services.AddTransient<IChatService, ChatService>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}
else
{
    app.UseExceptionHandler("/Home/Error");
    app.UseDeveloperExceptionPage();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllers();

app.Run();
